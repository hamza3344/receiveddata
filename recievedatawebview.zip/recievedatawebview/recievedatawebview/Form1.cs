﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace recievedatawebview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InitBrowser();
        }
        private async Task initizated()
        {
            await webView21.EnsureCoreWebView2Async(null);
        }
        public async void InitBrowser()
        {
            await initizated();
            webView21.CoreWebView2.Navigate("https://en.wikipedia.org/wiki/Wikipedia:About");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            getdata();
        }
        public async void getdata()
        {
            await webView21.ExecuteScriptAsync("window.chrome.webview.postMessage(document.getElementsByClassName('center')[0].innerHTML)");
        }

        private void webView21_WebMessageReceived(object sender, Microsoft.Web.WebView2.Core.CoreWebView2WebMessageReceivedEventArgs e)
        {
            MessageBox.Show(e.TryGetWebMessageAsString());
        }
    }
}
